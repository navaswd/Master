import React from 'react';
import { Formik, Field } from 'formik';
import { Container, Row, Col } from 'reactstrap';
import * as Yup from 'yup';
import classNames from 'classnames';

// Input feedback
const InputFeedback = ({ error }) =>
  error ? <div className={classNames('input-feedback')}>{error}</div> : null;

// Radio input
const RadioButton = ({
  field: {
    name, value, onChange, onBlur,
  },
  id,
  label,
  className,
  ...props
}) => (
    <div>
      <input
        name={name}
        id={id}
        type="radio"
        value={id} // could be something else for output?
        checked={id === value}
        onChange={onChange}
        onBlur={onBlur}
        className={classNames('radio-button')}
        {...props}
      />
      <label htmlFor={id}>{label}</label>
    </div>
  );

// Radio group
const RadioButtonGroup = ({
  value,
  error,
  touched,
  id,
  label,
  className,
  children,
}) => {
  const classes = classNames(
    'input-field',
    {
      'is-success': value || (!error && touched), // handle prefilled or user-filled
      'is-error': !!error && touched,
    },
    className
  );

  return (
    <div className={classes}>
      <fieldset>
        <legend>{label}</legend>
        {children}
        {touched && <InputFeedback error={error} />}
      </fieldset>
    </div>
  );
};

const onchangingradio = (e) => {
  console.log(e.target);
  let msg;
  if (e.target.value !== 'radioOption2') {
    msg = 'Nice try!';
  }
  return msg;
};


const RoofQuestionnew = (props) => (
  <div>
    <Container>
      {props.questionsData &&
        <section className="gaf-fiveq-panel">
          <h2>{props.questionsData.Title}</h2>
          <p>{props.questionsData.Description}</p>
          <Row className="justify-content-center">
            <Col sm={12} lg={9} xl={8}>
              <Row>
                <Col md={12}>
                  <Formik
                    initialValues={{
                      radioGroup: '',
                    }}
                    validationSchema={Yup.object().shape({
                      radioGroup: Yup.string().required('A radio option is required'),
                    })}
                    onSubmit={(values, actions) => {
                      setTimeout(() => {
                        console.log(JSON.stringify(values, null, 2));
                        actions.setSubmitting(false);
                      }, 500);
                    }}
                    render={({
                      handleSubmit,
                      values,
                      errors,
                      touched,
                      isSubmitting,
                    }) => {
                      return (
                        <form onSubmit={handleSubmit}>
                          {props.questionsData.SingleChoiceQuestions &&
                            props.questionsData.SingleChoiceQuestions.map((data, i) => {
                              
                            })}
                          <RadioButtonGroup
                            id="radioGroup"
                            label="One of these please"
                            value={values.radioGroup}
                            error={errors.radioGroup}
                            touched={touched.radioGroup}
                          >
                            <Field
                              component={RadioButton}
                              name="radioGroup"
                              id="radioOption1"
                              label="Choose this option"
                              onClick={(e) => onchangingradio(e)}
                            />
                            <Field
                              component={RadioButton}
                              name="radioGroup"
                              id="radioOption2"
                              label="Or choose this one"
                              onClick={(e) => onchangingradio(e)}
                            />
                          </RadioButtonGroup>
                          <button type="submit" disabled={isSubmitting}>
                            Submit
                          </button>
                        </form>
                      );
                    }}
                  />
                </Col>
              </Row>
            </Col>
          </Row>
        </section>
      }
    </Container>
  </div>
);
export default RoofQuestionnew;

/* import React from 'react';
import {Container, Row, Col, Button } from 'reactstrap';
import {Formik, Form, Field } from 'formik';
      
class RoofQuestionnew extends React.Component {
        constructor(props) {
      super(props);
    this.state = {
      };
    }
  
  componentDidMount() {
        // this.props.getAddress();
      }

      validateUsername = (value) => {
        console.log('test', value);
      let error;
    if (value === 'admin') {
        error = 'Nice try!';
      }
      return error;
    }
  
  render() {
    return (
      <div>
        <Formik
          initialValues={{
            username: '',
          }}
          onSubmit={(values) => {
            // same shape as initial values
            console.log(values);
          }}
        >
          {({
            errors, touched,
          }) => (
              <Form>
                <Field name="username" validate={(value) => this.validateUsername(value)} />
                {errors.username && touched.username && <div>{errors.username}</div>}
                <button type="submit">Submit</button>
              </Form>
            )}
        </Formik>
      </div>
      );
    }
  }
  export default RoofQuestionnew;
   */
